# Guía de PHP

El material está organizado según las temáticas indicadas en la [página oficial de Zend](http://www.zend.com/en/services/certification).
 
Esta guía no tiene ninguna relación con Zend.

## Es bienvenida cualquier modificación, arreglo o ampliación del contenido.